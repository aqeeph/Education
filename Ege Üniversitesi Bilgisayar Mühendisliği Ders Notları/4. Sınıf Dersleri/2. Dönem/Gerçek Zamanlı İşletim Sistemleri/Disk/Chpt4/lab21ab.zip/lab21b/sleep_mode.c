//*****************************************************************************
//
// Title: 		sleep_mode.c 
// Descrption: 	example shows the sleep-mode
//
// Author: 		Ralf Gessler; Heilbronn University, Campus K�N
// Date: 		Feb. 2012
// 
// Reference: 	LM3S1968 Firmware Development Package
//
//*****************************************************************************
//
// LM3S1968 Firmware Development Package
// CPU Usage
//
#include "utils/cpu_usage.h"
//
// Stellaris� Peripheral Driver Library
// System Control
// driverlib.lib
//
#include "driverlib/systick.h"
//
// Stellaris� Peripheral Driver Library
// SysTick
// driverlib.lib
//
#include "inc/hw_types.h" //tboolean
#include "driverlib/sysctl.h"

//
// The CPU usage for the most recent time period.
//
unsigned long g_ulCPUUsage;

//
// Handles the SysTick interrupt.
//
void
SysTickIntHandler(void)
{
//
// Compute the CPU usage for the last time period.
//
g_ulCPUUsage = CPUUsageTick();
}

//
// The main application.
//
int
main(void)
{
//
// Initialize the CPU usage module, using timer 0.
//
CPUUsageInit(8000000, 100, 0);
//
// Initialize SysTick to interrupt at 100 Hz.
//
SysTickPeriodSet(8000000 / 100);
SysTickIntEnable();
SysTickEnable();
//
// Loop forever.
//
while(1)
{
//
// Delay for a little bit so that CPU usage is not zero.
//
SysCtlDelay(100);
//
// Put the processor to sleep.
//
SysCtlSleep();
}
}
