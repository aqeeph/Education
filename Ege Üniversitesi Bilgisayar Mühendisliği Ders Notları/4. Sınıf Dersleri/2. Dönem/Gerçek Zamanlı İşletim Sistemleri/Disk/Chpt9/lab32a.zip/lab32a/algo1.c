//*****************************************************************************
//
// Title: 		algo1.c 
// Descrption: 	simple algorithm
//
// Author: 		Ralf Gessler; Heilbronn University, Campus K�N
// Date: 		Feb. 2012
//
// Reference: -
//
//*****************************************************************************

unsigned int k=5;
unsigned int i=10;

unsigned int y[100];

void main(void)
{
	while(1)
	{
		for (i=0;i<100;i++)
		{
			k=i*i;
			y[i]=k;
		}
	}
}
