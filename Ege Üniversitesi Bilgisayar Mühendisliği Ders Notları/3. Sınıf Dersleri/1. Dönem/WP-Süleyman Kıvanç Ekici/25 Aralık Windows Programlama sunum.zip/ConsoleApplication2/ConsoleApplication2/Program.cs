﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.Serialization;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 yeni = new Class1();
            yeni.isim = "cihat";
            yeni.yas = 22;
            IFormatter bicimlendirici = new BinaryFormatter();
            Stream akis = new FileStream("c:\\myFile.bin",FileMode.Create,FileAccess .Write);
            bicimlendirici.Serialize(akis,yeni);
            akis.Close();

            IFormatter bicimlendir = new BinaryFormatter();
            Stream akis2 = new FileStream("c:\\myFile.bin", FileMode.Open, FileAccess.Read);
            Class1 nesnem = (Class1)bicimlendir.Deserialize(akis2); 
            akis2.Close();

            Console.WriteLine("{0}",nesnem.yas);
            Console.WriteLine("{0}",nesnem.isim);
            Console.ReadLine();


        }
    }
}
