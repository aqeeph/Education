﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{   
    [Serializable]
    class Class1
    {
        public int yas;
        public string isim;


    }
}
