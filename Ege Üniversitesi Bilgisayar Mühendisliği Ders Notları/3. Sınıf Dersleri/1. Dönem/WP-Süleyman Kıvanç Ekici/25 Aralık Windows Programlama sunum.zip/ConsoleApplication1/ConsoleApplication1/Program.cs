﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            dosyaYaz();
            dosyadanOku("c:\\Deneme.txt");
            dosyayaEkle("c:\\Deneme.txt");
            Console.ReadLine();



        }
        static void dosyadanOku(string isim)
        {
            StreamReader dosya;
            string yazi;
            dosya = File.OpenText(isim);
            yazi = dosya.ReadLine();
            while (yazi != null)
            {
                Console.Write(yazi);
                yazi = dosya.ReadLine();
            }

            dosya.Close();
        }
        static void dosyayaEkle(string name)
        {
            StreamWriter dosya;
            dosya = File.AppendText(name);
            dosya.WriteLine("basariyla eklendi");
            dosya.Close();

        }
        static void dosyaYaz()
        {
            StreamWriter dosya = new StreamWriter("c:\\deneme.txt");
            dosya.WriteLine("ilk satir");
            dosya.WriteLine("ikinci satir");
            dosya.Close();
            Console.WriteLine("basarili");
            Console.ReadLine();




        }

    }
}
