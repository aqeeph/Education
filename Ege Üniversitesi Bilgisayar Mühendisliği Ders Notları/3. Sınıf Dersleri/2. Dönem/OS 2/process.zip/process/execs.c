execs.c
#include <sys/types.h>
#include <sys/wait.h>

char *env_init[]={ "USER=unknown", "PATH=/tmp", NULL};

int main(void)
{
 pid_t pid;
 
if ( (pid = fork() ) <0)
	printf("Fork error"), exit(1);

else if (pid==0) { /* specify path name, specify environment */
     if (execle("/usr/users/academic/kantarci/oslab/echoall",
		"echoall","myarg1","MYARG2",
		(char *)0, env_init) <0)
	 printf("execle error"), exit(1);
}
if (waitpid(pid, NULL, 0) < 0)
	 printf("Wait error"), exit(1); 
 
if ((pid = fork()) <0)
	 printf("Fork error"), exit(1); 
else if (pid == 0) { /* specify filename, inherit environment */
	if (execlp("echoall","echoall","only 1 arg", (char *) 0) <0)
		 printf("execlp error"), exit(1); 
}
exit(0);
}

echoall.c
