#include <stdio.h>

main()
{
 int pid;
 pid=fork();
 if (pid!=0)
 {
 while (1) 
   sleep(1000);
 }
 else
 {
 exit(0);
 }
}
