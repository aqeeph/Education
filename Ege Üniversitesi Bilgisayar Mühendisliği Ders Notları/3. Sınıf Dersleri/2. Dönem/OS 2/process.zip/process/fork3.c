/* wait for child to terminate with sleep() */
#include <stdio.h>

main()
{
int pid;
printf("I am the original process with PID %d and PPID %d.\n" ,
getpid(),getppid());
pid= fork();
if (pid!=0) /* parent */
{
 printf("I am the parent process with PID %d and PPID %d.\n", getpid(),
getppid());
 printf("My child's ppid is %d\n",pid);
 sleep(5);
}
else
{ /* child*/
 printf("I am the child process with PID %d and PPId %d\n",
getpid(),getppid());
}

printf("PID %d terminates\n", pid); /* both processes execute */
}
