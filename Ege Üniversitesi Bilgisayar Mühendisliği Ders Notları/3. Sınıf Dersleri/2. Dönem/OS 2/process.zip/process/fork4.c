#include <stdio.h>

main()
{
int pid, status, childpid;
printf("I am the original process with PID %d and PPID %d.\n" ,
getpid(),getppid());
pid= fork();
if (pid!=0) /* parent */
{
 printf("I am the parent process with PID %d and PPID %d.\n", getpid(),
getppid());
 childpid= wait(&status);
 printf("My child's ppid is %d. It is terminated with exit code %d\n",pid,
status >> 8);
}
else
{ /* child*/
 printf("I am the child process with PID %d and PPId %d\n",
getpid(),getppid());
exit(42);
}

printf("PID %d terminates\n", pid); /* both processes execute */
}
