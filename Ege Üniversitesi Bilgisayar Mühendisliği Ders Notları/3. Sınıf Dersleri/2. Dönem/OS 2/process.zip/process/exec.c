#include <stdio.h>

main()
{
execl("/bin/ls","ls","-l",NULL);
}
