HOMEWORK

1. Write a program that forks a child. The child will insert a signal handler with signal function and wait for  a signal. The parent will send a SIGINT signal. The signal handler will print when the signal arrives.

2. Repeat problem I. Implement it with sigaction function and use SIGUSR1 signal.



SOLUTIONS

HOMEWORK I


#include <unistd.h>
#include <signal.h>
#include <stdio.h>

static void SIGINT_handler(int);

main()
{
int pid;

if ((pid = fork ()) ==0) /* child */
{
 signal(SIGINT,SIGINT_handler);
 pause();
}
else 
{ 
 sleep(1);
 kill(pid, SIGINT);
 wait(0);
 exit(0);
}
}

void SIGINT_handler(int signo)
{
printf("Signal %d received from parent\n", signo);
exit(0);
}

HOMEWORK II

#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

main()
{
pid_t pid;

if ((pid = fork()) == 0) { /* child */
  struct sigaction action;
  void catchit();

  sigemptyset(&action.sa_mask);
  action.sa_flags=0;
  action.sa_handler= catchit;
  if (sigaction(SIGUSR1, &action, NULL) == -1)
	perror("sigusr: sigaction"), exit(1);
  pause();
}
else  { /*parent */
 int stat;
 sleep(1);
 kill(pid, SIGUSR1);
 pid= wait(&stat);
 printf("Child exit status = %d\n", WEXITSTATUS(stat));
 exit(0);
 }   
}

void catchit(int signo)
{
 printf("Signal %d received from parent\n",signo);
 exit(17);
}

