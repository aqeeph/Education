#include <unistd.h>
#include <signal.h>
#include <stdio.h>

main( argc, argv)
int argc;
char **argv;
{
void announce();
struct sigaction action;

if (argc != 2) 
  printf("Usage: %s seconds\n",argv[0]), exit(1);

sigemptyset(&action.sa_mask);

action.sa_flags=0;
action.sa_handler=announce;
sigaction(SIGALRM, &action, NULL);
alarm((unsigned) atoi(argv[1]));
pause();

puts("Main continues after signal handler");
exit(0);
}

void announce(signo)
 int signo;
{
printf("Received signal %d - Awake after alarm\n", signo);
}
