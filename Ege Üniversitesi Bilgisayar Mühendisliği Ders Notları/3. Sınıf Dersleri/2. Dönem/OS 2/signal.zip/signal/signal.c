#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

static void sig_usr(int);

int main(void)
{

 if (signal(SIGUSR1, sig_usr) == SIG_ERR) 
  perror("signal error"), exit(1);
 for (;;) pause();
}

void sig_usr(int signo)
{
 printf("SIGUSR1\n");
}
