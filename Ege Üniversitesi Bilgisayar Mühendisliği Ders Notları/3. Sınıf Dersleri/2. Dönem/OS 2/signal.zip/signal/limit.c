/*****************************************************/

// l 5 ls
// l 4 sleep 100
/*
1. The parent installs a SIGCHLD handler that is executed when its child
process terminates.
2. The parent forks a child process to execute the commend.
3. The parent sleeps for the specified number of seconds. When it wakes
up, it sends its child process a SIGINT signal to kill it.
4. If th echild terminates before its parent finishes sleeping , the
parent's SIGCHLD handler is executed, causing the parent to terminate
immediately.
*/
/*****************************************************/
#include <stdio.h>
#include <signal.h>

int delay;
childHandler();

main(argc, argv)
int argc;
char *argv[];
{
 int pid;
 signal(SIGCHLD, childHandler);
 pid=fork();
 if (pid == 0 )
 { /*child */
  execvp(argv[2],&argv[2]);
  perror("limit");
 }
 else
 { /*parent*/
  sscanf(argv[1], "%d", &delay);
  sleep(delay);
  printf("Child %d exceeded limit and is being killed \n",pid);
  kill(pid, SIGINT);
 }
}
/****************************************/

childHandler() /* Executed if th echild dies before the parent */
{
 int childPid, childStatus;
 childPid=wait(&childStatus);
 printf("Child %d terminated within %d seconds\n", childPid, delay);
 exit(0);
}
