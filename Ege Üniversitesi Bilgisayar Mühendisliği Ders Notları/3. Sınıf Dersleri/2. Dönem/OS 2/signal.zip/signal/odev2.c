#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

main()
{
pid_t pid;

if ((pid = fork()) == 0) { /* child */
  struct sigaction action;
  void catchit();

  sigemptyset(&action.sa_mask);
  action.sa_flags=0;
  action.sa_handler= catchit;
  if (sigaction(SIGUSR1, &action, NULL) == -1)
	perror("sigusr: sigaction"), exit(1);
  pause();
}
else  { /*parent */
 int stat;
 sleep(1);
 kill(pid, SIGUSR1);
 pid= wait(&stat);
 printf("Child exit status = %d\n", WEXITSTATUS(stat));
 exit(0);
 }   
}

void catchit(int signo)
{
 printf("Signal %d received from parent\n",signo);
 exit(17);
}
