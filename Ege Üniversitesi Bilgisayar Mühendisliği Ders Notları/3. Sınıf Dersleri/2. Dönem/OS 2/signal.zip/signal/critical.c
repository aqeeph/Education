/* sigsuspend sigintin de gecmesine izin veriyor */
#include <signal.h>
#include <errno.h>

static void sig_int(int);
int
main(void)
{
 sigset_t newmask, oldmask, zeromask;
 if (signal(SIGINT, sig_int) == SIG_ERR) exit(1);

 sigemptyset(&zeromask);
 sigemptyset(&newmask);

 sigaddset(&newmask, SIGINT);
		/* block SIGINT and save current signal mask */
 if (sigprocmask(SIG_BLOCK, &newmask, &oldmask) <0) exit(1);
 
		/* critical region of code */
 pr_mask(" in critical region: ");

		/* allow all signals and pause */

 if (sigsuspend(&zeromask) != -1) exit(1);

 pr_mask("after return from sigsuspend: ");

		/* reset signal mask which unblocks SIGINT */

 if (sigprocmask(SIG_SETMASK, &oldmask, NULL)< 0) exit(1);

 exit(0);

}

static void sig_int(int signo)
{
 pr_mask ("\n in sig_int : ");
 return;
}

void pr_mask(const char *str)
{
 sigset_t sigset;
 int errno_save;
 
 errno_save = errno;
 if (sigprocmask(0, NULL, &sigset) <0)  exit(1);

 puts(str);

 if (sigismember(&sigset, SIGINT)) printf("SIGINT ");
 if (sigismember(&sigset, SIGQUIT)) printf("SIGQUIT "); 
 if (sigismember(&sigset, SIGUSR1)) printf("SIGUSR1 "); 
 if (sigismember(&sigset, SIGALRM)) printf("SIGALRM "); 
 
 printf("\n");
 errno=errno_save;
}
