#include <stdio.h>
#include <signal.h>

main()
{
 int (*oldHandler) ();

 printf("I can be Control-C'ed\n");
 sleep(3);
 /* save the previous value of th esignal handler  */
 oldHandler=signal(SIGINT,SIG_IGN);
 printf("I am protected from Control-C now\n");
 sleep(3);
 signal(SIGINT, oldHandler);
 printf("I can be Control-C'd again\n");
 sleep(3);
 printf("bye");
}
