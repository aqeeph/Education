/* SIGSTOP : suspends a process
   SIGCONT : resume a process

The main program creates two children which both enters an infinite loop
and displays a message every second. The main program waited for three
seconds and then suspended the first child. The second child continues to
execute as usual. After another three seconds, the parent restarted th
efirst child, waited a little while longer, and then terminates both
children 

*/


#include <signal.h>
#include <stdio.h>

main()
{
 int pid1,pid2;

 pid1 = fork();
 if (pid1 == 0) 
 {
  while (1)
   {
    printf("pid1 is alive\n");
    sleep(1);
   }
 }  
 pid2 = fork();
 if (pid2 == 0)
 {
  while (1)
   {
    printf(" Pid2 is alive\n");
    sleep(1);
   }
 }
 sleep(3);
 kill(pid1, SIGSTOP);
 sleep(3);
 kill(pid1, SIGCONT);
 sleep(3);
 kill(pid1, SIGINT);
 kill(pid2, SIGINT);
}
