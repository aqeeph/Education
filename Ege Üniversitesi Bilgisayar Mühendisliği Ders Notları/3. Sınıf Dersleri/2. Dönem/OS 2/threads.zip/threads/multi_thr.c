/**************************************************/
// pthread_cleanup_pop u sil
/**************************************************/
#define _POSIX_C_SOURCE 19950L

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

void *sub_a(void *);
void *sub_b(void *);
void *sub_c(void *);
void *sub_d(void *);
void *sub_e(void *);

pthread_t thr_a, thr_b, thr_c, thr_d, thr_e;

pthread_attr_t attr;
int zero;

int time1()
{return(time(NULL)-zero);}



void *sub_a(void *arg)
{
 int err, i;
 pthread_t tid = pthread_self();
 
 printf("[%2d] A: \t In thread A\n", time1());
 sleep(1);
 pthread_create(&thr_d, &attr, sub_d, NULL);
 printf("[%2d] A: \t Created thread D\n", time1());
 sleep(3);
 printf("[%2d] A: \t Thread exiting...\n", time1());
 return ((void *)77);   
}

void *sub_b(void *arg)
{
 pthread_t tid = pthread_self();
 printf("[%2d] B: \t In thread B\n", time1());    


 sleep(4);
 printf("[%2d] B: \t Thread exiting...\n", time1());
 return ((void *)77);    
}  


void *sub_c(void *arg)
{
void *status;
int err,i;
pthread_t main_thr = (pthread_t) arg;
pthread_t tid = pthread_self();

printf("[%2d] C: \t In thread C\n", time1());    
sleep(2);

printf("[%2d] C: \t Joining main thread...\n", time1());
if (err=pthread_join(main_thr,&status))
 printf("pthread_join error, %s",strerror(err)), exit(1);

printf("[%2d] C: \t Main thread reurning status %d\n", time1(),(int)status); 

sleep(1);
pthread_create(&thr_b,&attr,(void *)sub_b, NULL);
printf("[%2d] C: \t Created thread B \n", time1());
sleep(4);
printf("[%2d] C: \t Thread exiting...\n", time1());
 return ((void *)88);    
}

static void *cleanup(void *arg)
{
pthread_t tid = pthread_self();
printf("[%2d] D: \t cancelled!\n", time1());
}
          
void *sub_d(void *arg)
{
int err,i;
pthread_t thr_e;
void *status;
pthread_t tid = pthread_self();

printf("[%2d] D: \t In thread D\n", time1());

pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
pthread_cleanup_push(cleanup, NULL);      
//pthread_cleanup_pop(0);
sleep(1);
pthread_create(&thr_e, &attr, (void *) sub_e, NULL);
printf("[%2d] D: \t Created thread E\n", time1());
sleep(5);

printf("[%2d] D: \t Thread exiting...\n", time1());
pthread_cleanup_pop(0);
 return ((void *)55);      

}

void *sub_e(void *arg)
{ int err,i;
void *status;
pthread_t tid= pthread_self();
printf("[%2d] E: \t In thread E \n", time1());
sleep(3);
printf("[%2d] E: \t Joining thread A\n", time1()); 
if (err=pthread_join(thr_c, &status))
 printf("pthread_join Error. %s", strerror(err)), exit(1);

if ((void *)status == (void *) PTHREAD_CANCELED)
 printf("[%2d] E: \t Thread D returning status:PTHREAD_CANCELED\n",time1());         
else
  printf("[%2d] E: \t Thread D returning status:%d\n", time1(), (int)status);
pthread_exit((void *)44);   
}


main()
{
pthread_t main_thr;
int err;
pthread_t tid=pthread_self();

zero=time(NULL);
main_thr=pthread_self();
printf("Time Thread \t Event\n");
printf("==== ====== \t =====\n");
printf("[%2d] Main: \t Mainthread started\n", time1());

pthread_attr_init(&attr);
pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);
pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

sleep(1);
pthread_create(&thr_a, &attr, (void *)sub_a, NULL);
printf("[%2d] Main: \t Created thread A\n", time1());  

sleep(1);
pthread_create(&thr_c, &attr, (void *)sub_c, (void *) main_thr);
printf("[%2d] Main: \t Created thread A\n", time1()); 
printf("[%2d] Main: \t Created thread C\n", time1());        

sleep(2);
//pthread_cleanup_push(cleanup, NULL);
printf("[%2d] Main: \t Cancelling thread D\n", time1());
pthread_cancel(thr_d);
//pthread_cleanup_pop(1);
sleep(1);
printf("[%2d] Main: \t Thread exiting.....\n", time1());
pthread_exit((void *) NULL);                

}
