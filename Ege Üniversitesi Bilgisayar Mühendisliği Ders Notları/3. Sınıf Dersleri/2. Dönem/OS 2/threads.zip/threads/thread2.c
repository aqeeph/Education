#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void thr_sub(void *);
pthread_mutex_t lock;
pthread_t a;
main()
{

int i, thr_count=5;
char buf;
pthread_attr_t attr;

pthread_attr_init(&attr); 
pthread_mutex_init(&lock,NULL);
pthread_mutex_lock(&lock);
printf("Creating %d threads\n", thr_count);
for (i=0; i< thr_count ; i++)
 {
  pthread_create(&a,&attr, (void *)&thr_sub, NULL);
 }
printf("%d threads have been created and are running ! \n",i);
printf("Press return to join all the threads\n ");
gets(&buf);

printf("Joining %d threads...\n",thr_count);
pthread_mutex_unlock(&lock);

for (i=0; i<thr_count ; i++)
  pthread_join(a,0);
printf("All %d threads have been joined, exiting ....\n", thr_count);
pthread_mutex_destroy(&lock);
return(0);
}

void thr_sub(void *arg)
{

pthread_mutex_lock (&lock);

printf("Thread %d is exiting \n", pthread_self());
pthread_mutex_unlock(&lock);
//return ((void *)0);
}
