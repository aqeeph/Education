#include <pthread.h>

#define NUM_THREADS 2
#define NUM_INCR 1

int shared_var;

pthread_mutex_t shared_var_lock= PTHREAD_MUTEX_INITIALIZER;

void inc_shared_var(int *x)
{
 int status, i;
 for (i=0; i< NUM_INCR; i++) {
   pthread_mutex_lock(&shared_var_lock);
   printf("CHILD %ld : The shared variable = %ld", *x, shared_var);
   shared_var ++;
   printf(", now is %ld\n", shared_var);
   pthread_mutex_unlock(&shared_var_lock);
 }
}


main()
{
	int *id_arg, thread_num, i, rtn, status;
	int done=0;
	pthread_t threads[NUM_THREADS];

	id_arg =  (int *)malloc(NUM_THREADS*sizeof(int));
	shared_var=0;
 	for (thread_num=0; thread_num< NUM_THREADS; thread_num++) {
	  id_arg[thread_num] = thread_num;
 	if ((rtn = pthread_create(&threads[thread_num], 
		NULL, (void *)inc_shared_var, 
		(void *)&id_arg[thread_num])) <0) {
		perror(rtn);
		exit();
	}
	}

for (thread_num=0; thread_num < NUM_THREADS;thread_num ++) {
 pthread_join(threads[thread_num], (void *)  &status);
printf("MASTER : joined to thread %ld \n", thread_num);
}
 printf("MASTER: Goodbye\n");
}


