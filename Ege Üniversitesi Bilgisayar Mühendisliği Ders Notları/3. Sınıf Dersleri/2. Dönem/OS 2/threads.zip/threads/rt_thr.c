#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <sched.h>

void *thr1(void *);
void *thr2(void *);
/********************************/
main()
{
pthread_attr_t attr1,attr2;
pthread_t tid1,tid2;
struct sched_param para1,para2;

pthread_attr_init(&attr1);
pthread_attr_init(&attr2);
pthread_attr_setscope(&attr1, PTHREAD_SCOPE_PROCESS);
pthread_attr_setdetachstate(&attr1, PTHREAD_CREATE_DETACHED);
pthread_attr_setscope(&attr2, PTHREAD_SCOPE_PROCESS);
pthread_attr_setdetachstate(&attr2, PTHREAD_CREATE_DETACHED); 
pthread_attr_setschedpolicy(&attr1, SCHED_OTHER);
pthread_attr_setschedpolicy(&attr2, SCHED_OTHER);    
para1.sched_priority=sched_get_priority_min(SCHED_OTHER);
para2.sched_priority=sched_get_priority_max(SCHED_OTHER);
pthread_attr_setschedparam(&attr1,&para1);
pthread_attr_setschedparam(&attr2,&para2);
pthread_create(&tid1, &attr1, thr1, NULL);
pthread_create(&tid2, &attr2, thr2, NULL);
sleep(10);
exit(0);
}
/********************************/
void *thr1(void *arg)
{
printf("1111111");
pthread_exit(NULL);
}
/********************************/
void *thr2(void *arg)
{
printf("2222222");
pthread_exit(NULL);
}
