#include <sched.h>
main()
{
int min,max;
min=sched_get_priority_min(SCHED_OTHER);

max=sched_get_priority_max(SCHED_OTHER);
printf("OTHER %d %d\n",max,min);

min=sched_get_priority_min(SCHED_FIFO);

max=sched_get_priority_max(SCHED_FIFO);
printf("FIFO %d %d\n",max,min);
min=sched_get_priority_min(SCHED_SYS);

max=sched_get_priority_max(SCHED_SYS);
printf("SYS %d %d\n",max,min);

min=sched_get_priority_min(SCHED_RR);

max=sched_get_priority_max(SCHED_RR);
printf("RR %d %d\n",max,min);

min=sched_get_priority_min(SCHED_IA);

max=sched_get_priority_max(SCHED_IA);
printf("IA %d %d\n",max,min);

min=sched_get_priority_min(_SCHED_NEXT);

max=sched_get_priority_max(_SCHED_NEXT);
printf("NEXT %d %d\n",max,min);

}
