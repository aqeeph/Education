/* 2. argu pthread_attr_default  diye yazdir */
#include <pthread.h>

void  say_hello(int *x)
{
 int i;

 for (i=0 ; i<*x ; i++)
	printf("say hello(): Hello\n");
 pthread_exit (0);
}


main()
{
 int *num_times;
 pthread_t thread1;
 pthread_attr_t attr;

 pthread_attr_init(&attr); 
  num_times = (int *) malloc(sizeof (int));
  *num_times= 2;

 pthread_create(&thread1, &attr, (void *)say_hello, (void*)num_times);
 sleep(1);
 printf("main() : Goodbye\n");
}
