#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void sub_a(void *);
void sub_b(void *);
void sub_c(void *);

pthread_t thr_a, thr_b, thr_c;

main()
{
pthread_t main_thr;

main_thr= pthread_self();
printf("Main thread %d\n",main_thr);

if (pthread_create(&thr_a, NULL, (void *)&sub_a,NULL))
{
 perror("thread_a thread creation error");exit(1);
}

if (pthread_create(&thr_b, NULL, (void *)&sub_b,NULL))
{
 perror("thread_b thread creation error");exit("1");
 exit(1);
}

if (pthread_create(&thr_c, NULL, (void *)&sub_c,NULL))
{
 perror("thread_c creation error");exit(1);
}
sleep(2);
printf("main thread exiting");
pthread_exit((void *)&main_thr);
}
/***************************/
void sub_a(void *arg)
{
int i;
printf("In thread A");
for(i=0;i<10000;i++)
printf("thread_a exiting");
pthread_exit(0);
}
/*****************************/
void sub_b(void *arg)
{
int i;
printf("In thread B");
for (i=0; i<10000;i++);
printf("thread_b exiting ");
pthread_exit(0);
}
/******************************/
void sub_c(void *arg)
{
int i;
printf("In thread C");
for (i=0;i<10000;i++)
printf("THREAD_C EXITING");
pthread_exit(0);
}
