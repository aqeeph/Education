#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <mqueue.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define FILE_MODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP)
                                                              
int main(int argc, char **argv)
{
 if (argc != 2)
	printf("usage: semunlink <name>"),exit(1);
 sem_unlink(argv[1]);
 exit(0);
}
