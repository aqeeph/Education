#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define FILE_MODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP)
                                                              
int main(int argc, char **argv)
{
 int c, flags;
 sem_t *sem;
 unsigned int value;

 flags= O_RDWR | O_CREAT | O_EXCL;
 if (argc != 3) 
	printf("usage: semcreate <name> <value>\n"), exit(1);
 value=atoi(argv[2]);
 sem=sem_open(argv[1],flags, FILE_MODE, value);
 sem_close(sem);
 exit(0);
 
}
