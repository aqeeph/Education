/*
 * pComparable.java	v0.01
 *
 * Copyright(c) 1998, Particle
 */

public interface pComparable{
	public int compareTo(Object o);
}
