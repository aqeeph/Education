/*
 * pSimpleObject.java	v0.01
 *
 * Copyright(c) 1998, Particle
 */

public class pSimpleObject{
	int i;

	public pSimpleObject(){
		i = 0;
	}

	public int get(){
		return i;
	}

	public void set(int n){
		i = n;
	}
}

